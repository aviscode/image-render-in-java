package unittests;

import geometries.Plane;
import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.fail;

/**
 * @author Avi Rosenberg
 */
public class CylinderTest {


    /**
     * Test method for {@link geometries.Cylinder#getNormal(primitives.Point3D)}.
     */
    @Test
    public void testGetNormal() {
        fail("Not yet implemented");
    }

}

